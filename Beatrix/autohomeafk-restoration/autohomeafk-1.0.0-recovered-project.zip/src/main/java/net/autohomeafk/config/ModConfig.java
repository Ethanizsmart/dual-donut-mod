package net.autohomeafk.config;

public class ModConfig {
   public boolean enabled = false;
   public String command = "home";
   public double delayMinutes = 1.0;
   public double repeatIntervalMinutes = 0.5;
   public double toleranceRadius = 2.0;
   public boolean showHotbar = true;
   public boolean hasAnchor = false;
   public double anchorX = 0.0;
   public double anchorZ = 0.0;
}
